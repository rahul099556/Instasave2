# InstaSave Web

Next.js App Router web app for downloading public/authorized Instagram media.

## Important

Instagram does not provide a general official API that returns arbitrary downloadable media URLs for every public Reel/Post/Story. This project therefore uses a **server-side resolver adapter** rather than pretending that scraping the Instagram HTML will always work.

Configure a public-content resolver service in Vercel:

- `INSTAGRAM_RESOLVER_URL` — HTTPS endpoint accepting `POST {"url":"https://www.instagram.com/..."}` and returning JSON containing `videoUrl` and/or `imageUrl`.
- `INSTAGRAM_RESOLVER_API_KEY` — optional bearer token for that resolver.

The resolver must only return content that the requester is authorized to download and must not bypass private accounts, login requirements, DRM, or other access controls.

## Project structure

- `src/app/page.tsx` — UI
- `src/app/actions.ts` — server-side resolver call
- `src/app/api/resolve/route.ts` — validated resolver API endpoint

## Build

```bash
npm ci
npm run build
```
