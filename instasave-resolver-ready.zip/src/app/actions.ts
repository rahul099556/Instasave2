"use server";

function isPublicInstagramUrl(value: string) {
  try {
    const url = new URL(value.trim());
    return (
      url.protocol === "https:" &&
      (url.hostname === "instagram.com" || url.hostname === "www.instagram.com") &&
      /^\/(reel|reels|p|tv|stories)\//.test(url.pathname)
    );
  } catch {
    return false;
  }
}

export async function fetchInstagramMedia(url: string) {
  const sourceUrl = url?.trim();

  if (!sourceUrl || !isPublicInstagramUrl(sourceUrl)) {
    return { error: "Please enter a valid public Instagram Reel, Post, or Story link." };
  }

  // The resolver is intentionally server-side. It must be configured with
  // an authorized/public-content resolver service in Vercel.
  const resolverUrl = process.env.INSTAGRAM_RESOLVER_URL;

  if (!resolverUrl) {
    return {
      error:
        "Instagram resolver is not configured yet. Add INSTAGRAM_RESOLVER_URL in Vercel Environment Variables.",
    };
  }

  try {
    const response = await fetch(resolverUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
        ...(process.env.INSTAGRAM_RESOLVER_API_KEY
          ? { authorization: `Bearer ${process.env.INSTAGRAM_RESOLVER_API_KEY}` }
          : {}),
      },
      body: JSON.stringify({ url: sourceUrl }),
      cache: "no-store",
      signal: AbortSignal.timeout(10_000),
    });

    if (!response.ok) {
      return { error: "The media resolver could not process this public Instagram link." };
    }

    const data = await response.json();

    const videoUrl =
      typeof data?.videoUrl === "string"
        ? data.videoUrl
        : typeof data?.video_url === "string"
          ? data.video_url
          : null;

    const imageUrl =
      typeof data?.imageUrl === "string"
        ? data.imageUrl
        : typeof data?.image_url === "string"
          ? data.image_url
          : typeof data?.thumbnail === "string"
            ? data.thumbnail
            : null;

    if (!videoUrl && !imageUrl) {
      return { error: "No downloadable public media was returned by the resolver." };
    }

    return {
      success: true,
      data: {
        url: sourceUrl,
        imageUrl,
        videoUrl,
        isVideo: Boolean(videoUrl),
      },
    };
  } catch {
    return { error: "Unable to resolve this public Instagram link right now." };
  }
}
