import { NextRequest, NextResponse } from "next/server";

const ALLOWED_HOSTS = new Set(["instagram.com", "www.instagram.com"]);

function isAllowedInstagramUrl(value: string) {
  try {
    const u = new URL(value);
    return u.protocol === "https:" && ALLOWED_HOSTS.has(u.hostname);
  } catch {
    return false;
  }
}

function normalizeMedia(data: any, sourceUrl: string) {
  const videoUrl =
    typeof data?.videoUrl === "string" ? data.videoUrl :
    typeof data?.video_url === "string" ? data.video_url : null;

  const imageUrl =
    typeof data?.imageUrl === "string" ? data.imageUrl :
    typeof data?.image_url === "string" ? data.image_url :
    typeof data?.thumbnail === "string" ? data.thumbnail : null;

  if (!videoUrl && !imageUrl) return null;

  return {
    url: sourceUrl,
    imageUrl,
    videoUrl,
    isVideo: Boolean(videoUrl),
  };
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const sourceUrl = typeof body?.url === "string" ? body.url.trim() : "";

    if (!isAllowedInstagramUrl(sourceUrl)) {
      return NextResponse.json(
        { error: "Please enter a valid public Instagram URL." },
        { status: 400 }
      );
    }

    const resolverUrl = process.env.INSTAGRAM_RESOLVER_URL;
    if (!resolverUrl) {
      return NextResponse.json(
        {
          error:
            "The Instagram resolver is not configured. Add INSTAGRAM_RESOLVER_URL in Vercel Environment Variables.",
        },
        { status: 503 }
      );
    }

    const endpoint = new URL(resolverUrl);
    if (!["https:", "http:"].includes(endpoint.protocol)) {
      return NextResponse.json({ error: "Invalid resolver configuration." }, { status: 500 });
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10_000);

    try {
      const headers: Record<string, string> = {
        "content-type": "application/json",
        accept: "application/json",
      };

      const apiKey = process.env.INSTAGRAM_RESOLVER_API_KEY;
      if (apiKey) headers.authorization = `Bearer ${apiKey}`;

      const response = await fetch(endpoint.toString(), {
        method: "POST",
        headers,
        body: JSON.stringify({ url: sourceUrl }),
        cache: "no-store",
        signal: controller.signal,
      });

      if (!response.ok) {
        return NextResponse.json(
          { error: "The media resolver could not process this public Instagram URL." },
          { status: 502 }
        );
      }

      const data = await response.json();
      const media = normalizeMedia(data, sourceUrl);

      if (!media) {
        return NextResponse.json(
          { error: "No downloadable public media was returned by the resolver." },
          { status: 404 }
        );
      }

      return NextResponse.json({ success: true, data: media });
    } finally {
      clearTimeout(timeout);
    }
  } catch (error) {
    const message =
      error instanceof Error && error.name === "AbortError"
        ? "The media resolver timed out."
        : "Unable to resolve this public Instagram URL.";

    return NextResponse.json({ error: message }, { status: 500 });
  }
}
